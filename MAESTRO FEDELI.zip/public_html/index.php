<!DOCTYPE html>
<html> 
<head>

<title>Maestro Fedeli Cafe - About</title>
	<link href="logo.jpg" rel="icon" type="image">
	<link rel="stylesheet" type="text/css" href="project_main.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<script src="http://use.edgefonts.net/bebas-neue:n4:default;montserrat:n4:default.js" type="text/javascript"></script>
</head>
	
<header>
<br /> 
<br /> 
<center><img src="logo.jpg" width="12%" style="border-radius: 50%; border: 4px solid #ddd; padding: 2px;" ></center>
<br>
<div class="tab">
	<button class="active" onclick="window.location.href = 'main.html';">ABOUT US</button>
		<div class="dropdown">
	<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" style="margin-top: -10px; line-height: 1.5;">MENU</button>
		<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-body" style=""><img src="MF_Menu.JPG" alt="maestroCafeMenu" width="700"></div></div></div></div>
		<div class="dropdown-content">
		<a href="mainCourse.html"><p class="subMenu">Main Course</p></a>
		<a href="drinks.html"><p class="subMenu">Drinks</p></a>
		<a href="desserts.html"><p class="subMenu">Desserts</p></a>
		</div>
		</div>
	<button onclick="window.location.href = 'gallery.html';">GALLERY</button>
	<button onclick="window.location.href = 'testimonials.html';">TESTIMONIALS</button>
	<button onclick="window.location.href = 'contactus.html';">CONTACT US</button>
	<button onclick="window.location.href = 'survey.html';">SURVEY</button>
</div>
</header>
<body>

<div class="content1 container">
	<div class="line1"></div>
	<div class="main1">
		<img src="main-info-pic1.jpg" class="main_photo1" alt="Main Page Picture - Coffee">
		<div class="main_info">
			<h3 class="main_header"> <a id="about_us">WHO WE ARE</a> </h3> <br />
			<p class="main_text" style="padding-right: 40%;"> Bringing you our signature drinks, good food, and chill music sessions from Laguna, Maestro Fedeli Cafe is a small but thriving
			business that has lots to offer. <br /> <br /> Our cafe serves the most aromatic coffee and delightful meals that not only fills your stomach but also 
			your soul as you immerse yourself in the cafe's comfy and serene ambiance.	<br /> <br /> We make our products with love and expertise that, we 
			guarantee, will leave you wanting more. </p>
		</div>
	</div>
</div>
<div class="content2 container">
	<div class="line1"></div>
	<div class="main1">
		<img src="main-info-pic2.jpg" class="main_photo1" alt="Main Page Picture - Cafe Exterior">
		<div class="main_info1">
			<h3 class="main_header"> <a id="background">OUR BACKGROUND</a> </h3> <br />
			<p class="main_text"> In September 2014, a dream business finally came to reality for the Gatdula family when the son, now manager Louie Elbern 
			Gatdula, decided to provide the class service he learned from Dubai here to our homeland. <br /><br /> Although coming from a big loss from a
			failed business in line with spa and facial care, still filled with determination and anchored faith, pursued to serve quality coffee, pasta 
			and sandwiches in its surrounding community. </p>
		</div>
	</div>
	<div class="line2"></div>
	<div class="main2">
		<a href=""></a>
		<img src="main-info-pic3.jpg" class="main_photo2" alt="Main Page Picture - Cafe Interior">
		<div class="main_info2">
			<p class="main_text"> Inspired from a story in the bible, (see 1 Kings 17:7-16)<br /> when the prophet Elijah spoke to a widow of the Lord's <br />
			faithfulness to man even with the littlest and last resources we have, combined with the Italian origin of its coffee blend,
			thus the name Maestro Fedeli Cafe, which translates to Faithful Master in the English language. </p>
		</div>
	</div>
	<div class="line1"></div>
	<div class="main1" style="margin-bottom: 17%;">
		<img src="main-info-pic4.jpg" class="main_photo1" alt="Main Page Picture - Cafe Window" style="margin-top:-9%;">
		<div class="main_info1">
			<p class="main_text">Being a family-owned business, the manager, Louie Elbern Gatdula, with his cousin, Ramil Coronado, both had excellent 
			experience abroad in line with service and management industries with focus on coffee and barista skills. Together, they have been training 
			their staff, innovating coffee concoctions, and striving to serve quality coffee, and provide good coffee experience to all its clients. </p>
		</div>
	</div>
</div>
<div class="container">
	<div class="main_events table-responsive-md">
		<table class="events_table" cellpadding="20px">
		<tbody>
			<th colspan="3">
				<h5 style="letter-spacing: 4px; text-align: center;"><a id="events">RECENT EVENTS</a></h5>
			</th>
			<tr>
				<td>
					<div class="events_content">
						<a href="https://www.facebook.com/maestrofedeli/photos/a.321853894653850/1201494543356443/?type=3&theater">
							<img src="ccoustic.jpg" alt="Music Cafe Session"><br /> 
						<h6>Coffeecoustic</h6>
						<div class="more_details">
							<p>#coffeecoustic saturday!<br /> Kape, milk tea, pasta at musika! Kitakits tayo!</p>
						</div>
						</a>
					</div>
				</td>
				<td>
					<div class="events_content">
						<a href="https://www.facebook.com/maestrofedeli/photos/a.321853894653850/1198680223637875/?type=3&theater">
							<img src="holidaypromo.jpg" alt="Milk Tea Holiday Promo"> <br /> 
						<h6>Araw ng KagiTEAngan</h6>
						<div class="more_details">
							<p>Call all those <i>magigiTEAng</i>!!!<br /> Come try our new milk tea flavors, available on April 9.</p>
						</div>
						</a>
					</div>
				</td>
				<td>
					<div class="events_content">
						<a href="https://www.facebook.com/maestrofedeli/photos/a.321853894653850/1185555138283717/?type=3&theater">
							<img src="bdaypromo.jpg" alt="Owner Birthday Promo"><br />
						<h6>Maestro's Birthday</h6>
						<div class="more_details">
							<p>Inviting you all to the maestro's very own birthday bash! We're giving a 10% discount on all of our drinks on March 22-24. </p>
						</div>
						</a>
					</div>
				</td>
			</tr>
			</tbody>
		</table>
	</div>
</div>
</body>
<footer align="center" style="font-size:20px">
<div class="container-fluid">
<br>
<a href="https://www.google.com/"><img src="glogo.png" alt="google logo" width="50" height="50" style="border-radius: 5px;" hspace="5"></a>
<a href="https://www.facebook.com/"><img src="fblogo.png" alt="fb logo" width="50" height="50" hspace="5"></a>
<br><br>
<small> 
<p style="font-family: Tahoma; color: white;">Angelica Adriano | Jo Simon Ambata | Dan Jacinto | Ethan Moncayo<br>
&copy Copyright Information 2019  </p>
<br>
</small>
</div>
</footer>

</html>